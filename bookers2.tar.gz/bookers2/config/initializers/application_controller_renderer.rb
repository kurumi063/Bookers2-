# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = 'a1a5f0c26b46e2642f733ffa2d059149a801c1c39e515e041f72c9795ff80b4678965b0fd766ee53b6c91c49c79e411f7196a6f72b5bea946db8f4eb214bcdff'
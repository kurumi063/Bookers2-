class UsersController < ApplicationController
  def index
   @user = current_user
   @book = Book.new
   @books = Book.all
    @users = User.all
  end

  def show
   @book = Book.new
   @books = Book.all
   @user = current_user
  end

  def edit
   @user = User.find(params[:id])
  end

  def create
    @book = Book.new
    if @book.save
    redirect_to books_path
    else
       @books = Book.all
       render :show
    end
  end

  def update
     @user = User.find(params[:id])
     if @user.update(user_params)
       flash[:notice] = "You have updated user successfully."
       redirect_to user_path(@user)
     else
       render :edit
     end
  end


  private

  def user_params
     params.require(:user).permit(:profile_image,:name,:introduction)
  end


end

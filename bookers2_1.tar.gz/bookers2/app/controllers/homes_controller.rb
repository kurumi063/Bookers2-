class HomesController < ApplicationController
  def top
  end

def index
    @book = Book.new
    @books = Book.all
end


def show
    @home = current_user
end



  def about
   @home = current_user
  end
end
